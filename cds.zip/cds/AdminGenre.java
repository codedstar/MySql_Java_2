/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.kwaku.cds;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author kwaku
 */

//        String url = "jdbc:mysql://localhost:3306/music";
//        String username = "root";
//        String password = "root";


public class AdminGenre {
    Connection conn;
    private String url;
    private String username;
    private String password;
    
    public AdminGenre( String url,String username,String password){
        this.url = url;
        this.username = username;
        this.password = password;
    }
    
    public String connet(){

        try{
            conn = DriverManager.getConnection(url,username,password);
            return "connection successful";
            
        }catch(SQLException exception){
            return "Error" + exception.getMessage();
        }
        
    }
    
    public String insertGenre(String genreName){
        try{
            // PreparedStatement way
            String query = "INSERT INTO genre(name) VALUES(?)";
            PreparedStatement pStmt = conn.prepareStatement(query);
            pStmt.setString(1, genreName);

            int pStmtRowsAffected = pStmt.executeUpdate();
            return pStmtRowsAffected + " row(s) inserted.";
            
        }catch(SQLException exception){
             return "Error" + exception.getMessage();
        }
    }
    
    public String updateGenre(String genreName, int id){
        try{
            // PreparedStatement way
            String query = "UPDATE `music`.`genre` SET `name` = ? WHERE (`id_genre` = ?)";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, genreName);
            statement.setInt(2, 1);

            int rowsUpdated = statement.executeUpdate();
            return rowsUpdated + " row(s) updated successfully.";

            
        }catch(SQLException exception){
             return "Error" + exception.getMessage();
        }
    }
        
    public String deleteGenre(int id){
        try{
            // PreparedStatement way
            String query = "DELETE FROM `music`.`genre` WHERE (`id_genre` = ?)";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setInt(1, 1);
            int rowsDeleted = statement.executeUpdate();
            return rowsDeleted + " row(s) deleted successfully.";
            
        }catch(SQLException exception){
             return "Error" + exception.getMessage();
        }
    }
}
